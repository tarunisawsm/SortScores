﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace SortScores.Test
{
    [ TestClass ]
    class SortScoresTest
    {
        [TestMethod]
        public void shouldThrowErrorForInvalidPath()
        {
            GradeScores testFile = new GradeScores();
            string fileName = "abc";
            bool retResult = testFile.setInputFilePath(fileName);
            Assert.IsTrue(retResult.Equals(false));
            
        }

        [TestMethod]
        public void shouldThrowErrorForEmptyFile()
        {
            GradeScores testFile = new GradeScores();
        }

        [TestMethod]
        public void shouldSetInputFilePath()
        {

        }

        [TestMethod]
        public void shouldSortFileContent()
        {

        }

        [TestMethod]
        public void shouldWriteOutputFileData()
        {

        }
    }
}
